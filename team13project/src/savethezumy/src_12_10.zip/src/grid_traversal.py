#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#This is an EXECUTABLE node that will INITIALIZE the UR5 sequence

#TASKS:
# 1) Create Grid Array
# 2) Forward Kinematics to move to favorable position
# 3) Inverse Kinematics to move UR5 over 1st corner AR_tag

#FUNCTIONS:
# -move_XY()
# -test_Z()

#VARIABLES:
# -ar_array

#More dependencies
import tf
import pdb
import rospy
import sys
import math
from math import pi
import numpy as np
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform, Vector3, Wrench
import ar_tag_grid as artg
import numpy as np
import time
import roslib; roslib.load_manifest('ur_driver')
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
from time import time
# import inverse_kinematics as IK USE VALMIK CODE
# import map_tool_frame as MTF

forceReading = None

#PRIMARY METHODS

#def grid_gen():
def move_XY(corner_tag, ar_tag_nums, spacing):

    #Input joint_angles
    #1x6 array of UR5 joint angles

    ##Solve for robot initial states
    #initial_pos = MTF.map_to_tool(joint_states)

    ##Solve XY IK solution
    #final_states = IK.solveXY(corner_tag,desired_pos,initial_pos)

    ##Set movement speed
    #This is the default speed (i.e. time to this position) in test_move
    move_speed = 2.0

    g = FollowJointTrajectoryGoal()
    g.trajectory = JointTrajectory()
    g.trajectory.joint_names = JOINT_NAMES
    try:
        g.trajectory.points = [
            JointTrajectoryPoint(positions=joints_states, velocities=[0]*6, time_from_start=rospy.Duration(0.0)),
            JointTrajectoryPoint(positions=final_states, velocities=[0]*6, time_from_start=rospy.Duration(move_speed))]
        client.send_goal(g)
        client.wait_for_result()
    except KeyboardInterrupt:
        client.cancel_goal()
        raise
    except:
        raise

    #Move the UR5 to first corner of the grid by calling Valmik IK function
    

# def init_favorable_pos():
def test_Z(favorable_pos,joint_states,client,JOINT_NAMES):

    #Input joint_angles
    #1x6 array of UR5 joint angles
    global forceReading

    rospy.init_node('test_z', anonymous=True)

    #Create instance of force sensor subscriber
    force_sensor_sub = rospy.Subscriber("ati_ft_data", Wrench, force_sensor_callback)

    ##Solve for robot initial states
    #initial_pos = MTF.map_to_tool(joint_states)

    ##Solve XY IK solution
    #final_states = IK.solveXY(corner_tag,desired_pos,initial_pos)

    ##Set movement speed
    #This will be MUCH slower so we will set a velocity variable here to calculate time
    #z_dist = 2 in travel
    move_time_slow = 5.0
    move_time = 2.0

    ##SENSOR sample time == approx. 0.008 seconds

    g = FollowJointTrajectoryGoal()
    g.trajectory = JointTrajectory()
    g.trajectory.joint_names = JOINT_NAMES
    try:
        joint_states = rospy.wait_for_message("joint_states", JointState)
        above_block = joint_states.position
        g.trajectory.points = [
            JointTrajectoryPoint(positions=above_block, velocities=[0]*6, time_from_start=rospy.Duration(0.0)),
            JointTrajectoryPoint(positions=final_states, velocities=[0]*6, time_from_start=rospy.Duration(move_time_slow))]
        
        #Do not insert a wait_for_result in order to allow for interrupts
        client.send_goal(g)

        #Get force value from sensor
        vector_force = forceReading.force
        #Calculate a force value from force vector
        #value_force = np.sqrt(np.dot(vector_force,vector_force))
        value_force_calib = vector_force.z

        value_force = abs(forceReading.force.z - value_force_calib)

        start_time = time()
        current_time = time()
        #listen to the FORCE value
        while abs(current_time - start_time) < move_time_slow:
            if value_force > 50:
                print "Interrupting Wood Block Detected"
                joint_states = rospy.wait_for_message("joint_states", JointState)
                joints_pos = joint_states.position
                g.trajectory.points = [
                    JointTrajectoryPoint(positions=joints_states, velocities=[0]*6, time_from_start=rospy.Duration(0.0)),
                    JointTrajectoryPoint(positions=final_states, velocities=[0]*6, time_from_start=rospy.Duration(move_time))]
                client.send_goal(g)
                client.wait_for_result()

            value_force = abs(forceReading.force.z - value_force_calib)
            #update time
            current_time = time()

    except KeyboardInterrupt:
        client.cancel_goal()
        raise
    except:
        raise

    #Move the UR5 to first corner of the grid by calling Valmik IK function

def force_sensor_callback():

    global forceReading
    forceReading = message

