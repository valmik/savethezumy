#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#This is an EXECUTABLE node that will use JOINT STATES to compute where the tool frame is relative to AR_TAGs

#TASKS:
# 1) Create Grid Array

#FUNCTIONS:
# -map()

#VARIABLES:
# -ar_array

#More dependencies
import tf
import pdb
import rospy
import sys
import math
from math import pi
import numpy as np
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform, Vector3
import ar_tag_grid as artg
import numpy as np
import time
import roslib; roslib.load_manifest('ur_driver')
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *

# import inverse_kinematics as IK USE VALMIK CODE

listener = None

#PRIMARY METHODS

#def grid_gen():
def map_to_tool(joint_states):
    
    

    

