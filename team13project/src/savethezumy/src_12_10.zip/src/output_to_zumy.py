#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#This is an EXECUTABLE node that will gather 

#TASKS:
# 1) Create Grid Array
# 2) Forward Kinematics to move to favorable position

#FUNCTIONS:
# -create_output()
# -publish_to_zumy()

#VARIABLES:
# -ar_array

#More dependencies
import tf
import pdb
import rospy
import sys
import math
from math import pi
import numpy as np
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform, Vector3
import ar_tag_grid as artg
import numpy as np
import time
import roslib; roslib.load_manifest('ur_driver')
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *

listener = None

#PRIMARY METHODS

#def grid_gen():
def create_output(gridArray):

	## USE DP! :)
	# Cost Function
	# 1) number of Steps to solution
	# 2) number of Zumy turns!

    return zumyPath

#def grid_gen():
def publish_to_zumy(zumyPath):

	#generate a text file for Zumy to read from!
	with open('toZumy.txt', 'w') as f:
		print >> f,zumyPath
    