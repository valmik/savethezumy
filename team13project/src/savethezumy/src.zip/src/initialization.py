#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#This is an EXECUTABLE node that will INITIALIZE the UR5 sequence

#TASKS:
# 1) Create Grid Array
# 2) Forward Kinematics to move to favorable position
# 3) Inverse Kinematics to move UR5 over 1st corner AR_tag

#FUNCTIONS:
# -grid_gen()
# -favorable_pos()
# -move_to_start()

#VARIABLES:
# -ar_array

#More dependencies
import tf
import pdb
import rospy
import sys
import math
import numpy as np
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform, Vector3
import time

jointState = None

#PRIMARY METHODS
# def grid_gen():


# def favorable_pos():


# def move_to_start():

#ALL CALLBACK FUNCTIONS used w/ Listener nodes
def joint_state_callback(message):

    #Print the contents of the message to the console
    
    global jointState
    jointState = message
   
    # print(rospy.get_name() + ": I heard %s" % message.data)

    #Python's syntax for a main() method

#USEFUL MATH FUNCTIONS
def return_rbt(trans, rot):
    """
    Prints out the 4x4 rigid body transformation matrix from quaternions

    Input:
        (3,) array - translation ector
        (4,) array - rotation vector in quaternions
    """

    [omega, theta] = eqf.quaternion_to_exp(rot)

    g = eqf.create_rbt(omega, theta, trans)

    return g

def compute_twist(rbt):
    """
    Computes the corresponding twist for the rigid body transform

    Input:
        rbt - (4,4) ndarray 

    Output:
        v - (3,) array
        w - (3,) array
    """

    R = rbt[0:3][:,0:3]
    trans = rbt[0:3][:,3:4]

    [omega, theta] = eqf.find_omega_theta(R)

    v = eqf.find_v(omega, theta, trans)

    #pdb.set_trace()

    v = np.array([v[0,0],v[1,0],v[2,0]])

    twist = np.array([v[0],v[1],v[2],omega[0],omega[1],omega[2]])

    return twist

if __name__=='__main__':
    
    #initialize listerner node!
    rospy.init_node('listener', anonymous=True)

    #Create instances of subscriber objects
    joint_state_sub = rospy.Subscriber("joint_states", JointState, joint_state_callback)
    
    print("Position: %s" % str(jointState))
    time.sleep(5)
    print("Position: %s" % str(jointState.position))
    time.sleep(5)
    print("Position: %s" % str(jointState.position))
    time.sleep(5)
    print("Position: %s" % str(jointState.position))
        
    rospy.spin()


















    # rospy.init_node('ar_tags_subs')
    # if len(sys.argv) < 4:
    #     print('Use: ar_tag_subs.py [ AR tag number ] [ AR tag number ] [ AR tag number ] ')
    #     sys.exit()
    # ar_tags = {}
    # ar_tags['ar0'] = 'ar_marker_' + sys.argv[1]
    # ar_tags['ar1'] = 'ar_marker_' + sys.argv[2]
    # ar_tags['arZ'] = 'ar_marker_' + sys.argv[3]

    # listener = tf.TransformListener()

    # rate = rospy.Rate(10.0)
    # while not rospy.is_shutdown():
        
    #     try:
    #         (trans, rot) = listener.lookupTransform(ar_tags['arZ'], ar_tags['ar1'], rospy.Time(0))
    #         rot = np.array(rot)
    #         rbt = return_rbt(trans=trans, rot=rot)
    #         print('gab between ' + ar_tags['arZ'] + ' and ' + ar_tags['ar1'])
    #         print rbt
    #         twist = compute_twist(rbt=rbt)
    #         print('twist between ' + ar_tags['arZ'] + ' and ' + ar_tags['ar1'])
    #         print twist
    #     except Exception as e:
    #         print(e)
            
    #     rate.sleep()

        