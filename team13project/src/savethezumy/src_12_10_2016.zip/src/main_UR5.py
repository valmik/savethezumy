#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#This is an EXECUTABLE node that will INITIALIZE the UR5 sequence

#TASKS:
# 1) run code in sequence

#FUNCTIONS:
# -joint_state_callback()
# -force_sensor_callback()
# -run()

#VARIABLES:
# -JOINT_NAMES 
# -client 
# -jointState 
# -forceReading 
# -gridArray 
# -zumyPath 

#More dependencies
import roslib; roslib.load_manifest('ur_driver')
import rospy
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
from sensor_msgs.msg import JointState
from math import pi
import tf
import pdb
import rospy
import sys
import math
import numpy as np
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform, Vector3
import time
#IMPORT other .py files!
import initialization as INIT
import grid_traversal as GRTR
import output_to_zumy as OTZ

JOINT_NAMES = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
               'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']

#instantiate GLOBAL variables to store 
client = None
jointState = None
forceReading = None
gridArrayIDs = None
gridArrayValues = None
zumyPath = None

#ALL CALLBACK FUNCTIONS used w/ Listener nodes
def joint_state_callback(message):

    #Print the contents of the message to the console
    
    global jointState
    jointState = message
   
    # print(rospy.get_name() + ": I heard %s" % message.data)

def force_sensor_callback(message):

    #Print the contents of the message to the console
    
    global forceReading
    forceReading = message
   
    # print(rospy.get_name() + ": I heard %s" % message.data)

def run():

    #########################################################################################
    # 0) General Setup
    #initialize listerner node!
    rospy.init_node('main', anonymous=True)

    #rospy.spin()

    #print("Sub")
    #Create instances of subscriber objects
    joint_state_sub = rospy.Subscriber("joint_states", JointState, joint_state_callback)
    #force_sensor_sub = rospy.Subscriber("ati_ft_data", Wrench, force_sensor_callback)

    #########################################################################################
    # 1) Create Grid Array
    #number of the AR_TAG at the start corner
    corner_tag = 10
    #array of the 25 AR_TAG numbers that are in use on the grid
    ar_tag_nums = np.array([6,5,7,8,9,10,11,12,13,14,19,20,21,22,23,25])
    #the known distance between ar_tags (i.e. equivalent of 5 inches in whatever are desired units)
    spacing = 0.13

    print("Generating Grid")
    global gridArrayIDs
    gridArrayIDs = INIT.grid_gen(corner_tag,ar_tag_nums,spacing)
    #Check
    print(gridArrayIDs)

    inp = raw_input("Move to favorable position? y/n: ")

    #########################################################################################
    # 2) Forward Kinematics to move to favorable position
    #Capture current joint states in an array 
    joint_states = jointState.position

    #Hard code in a Favorable Position that is close to the grid
    #This must be a 1x6 array input like in test_move.py code
    ## SET THIS AS A POSITION WITH TOOL FRAME AT THE Z HEIGHT WE WANT
    favorable_pos = [0.51, -2.17, -1.18, -1.37, 1.53, 0] 

    print "This program will now make the robot move between the initial state:"
    print str([joint_states[i]*180./pi for i in xrange(0,6)])
    print "To the favorable state:"
    print str([favorable_pos[i]*180./pi for i in xrange(0,6)])
    print "Please make sure that your robot can move freely between these poses before proceeding!"

    global client
    try:
        client = actionlib.SimpleActionClient('follow_joint_trajectory', FollowJointTrajectoryAction)
        print "Waiting for server..."
        client.wait_for_server()
        print "Connected to server"
        parameters = rospy.get_param(None)
        index = str(parameters).find('prefix')
        if (index > 0):
            prefix = str(parameters)[index+len("prefix': '"):(index+len("prefix': '")+str(parameters)[index+len("prefix': '"):-1].find("'"))]
            for i, name in enumerate(JOINT_NAMES):
                JOINT_NAMES[i] = prefix + name
        
        print "This program will now make the robot move between the initial state:"
        print str([joint_states[i]*180./pi for i in xrange(0,6)])
        print "To the favorable state:"
        print str([favorable_pos[i]*180./pi for i in xrange(0,6)])
        print "Please make sure that your robot can move freely between these poses before proceeding!"
        
        inp = raw_input("Move to favorable position? y/n: ")[0]
        if (inp == 'y'):
            INIT.init_favorable_pos(favorable_pos,joint_states,client,JOINT_NAMES)
        else:
            print "Halting program"

    except KeyboardInterrupt:
        rospy.signal_shutdown("KeyboardInterrupt")
        raise

    #########################################################################################
    # 3) Inverse Kinematics to move UR5 over 1st corner AR_tag

    #Capture current joint states in an array 
    joint_states = jointState.position

    try:
        print "This program will now make the robot move to the corner of the grid:"
        print "Please make sure that your robot can move freely between these poses before proceeding!"
        
        inp = raw_input("Move to corner position? y/n: ")[0]
        if (inp == 'y'):
            INIT.move_to_start(corner_tag,desired_pos,joint_states,client,JOINT_NAMES)
        else:
            print "Halting program"

    except KeyboardInterrupt:
        rospy.signal_shutdown("KeyboardInterrupt")
        raise

    #########################################################################################
    # 4) TRAVESE GRID

    #Generate array to keep track of good or bad blocks that is the same size as the gridArrayIDs
    gridArrayValues = np.zeros((1,np.size(gridArrayIDs)))

    #Loop through the testing method i = number of ar_tag times
    iterations_num = ar_tag_nums.size

    try:
        for i in range(0,ar_tag_nums.size): #loop over number of tags
            
                if (i+1)%boardLength==0: #check if at end
                     if (abs(x)<tol)&((y < (yspacing+tol)) & (y > (yspacing-tol))):
                        grid[i+1]=nextTag
                        direction = direction*-1
                        break
                elif (abs(y)<tol)& (abs(x) < (xspacing+tol)) & (abs(x) > (xspacing-tol)) & (direction*x>0):
                        grid[i+1]=nextTag
                        break
    except Exception as e:
        print(e)

    #########################################################################################
    # 5) SEND OUTPUT TO ZUMY

    #Using the tested gridArrayValues generate an array of ar_tag numbers
    zumyPath = OTZ.create_output(gridArrayValues)

    #Publish the array to somewhere for the Zumy to pick it up!
    OTZ.publish_to_zumy(zumyPath)

    rospy.spin()

if __name__=='__main__': 
    run()



# TEST
# print("Position: %s" % str(jointState))
# time.sleep(5)
# print("Position: %s" % str(jointState.position))
    

# #USEFUL MATH FUNCTIONS
# def return_rbt(trans, rot):
#     """
#     Prints out the 4x4 rigid body transformation matrix from quaternions

#     Input:
#         (3,) array - translation ector
#         (4,) array - rotation vector in quaternions
#     """

#     [omega, theta] = eqf.quaternion_to_exp(rot)

#     g = eqf.create_rbt(omega, theta, trans)

#     return g

# def compute_twist(rbt):
#     """
#     Computes the corresponding twist for the rigid body transform

#     Input:
#         rbt - (4,4) ndarray 

#     Output:
#         v - (3,) array
#         w - (3,) array
#     """

#     R = rbt[0:3][:,0:3]
#     trans = rbt[0:3][:,3:4]

#     [omega, theta] = eqf.find_omega_theta(R)

#     v = eqf.find_v(omega, theta, trans)

#     #pdb.set_trace()

#     v = np.array([v[0,0],v[1,0],v[2,0]])

#     twist = np.array([v[0],v[1],v[2],omega[0],omega[1],omega[2]])

#     return twist



        