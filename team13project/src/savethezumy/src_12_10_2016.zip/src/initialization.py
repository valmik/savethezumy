#!/usr/bin/env python
#The line above tells Linux that this file is a Python script,
#and that the OS should use the Python interpreter in /usr/bin/env
#to run it. Don't forget to use "chmod +x [filename]" to make
#this script executable.

#This is an EXECUTABLE node that will INITIALIZE the UR5 sequence

#TASKS:
# 1) Create Grid Array
# 2) Forward Kinematics to move to favorable position
# 3) Inverse Kinematics to move UR5 over 1st corner AR_tag

#FUNCTIONS:
# -grid_gen()
# -favorable_pos()
# -move_to_start()

#VARIABLES:
# -ar_array

#More dependencies
import tf
import pdb
import rospy
import sys
import math
from math import pi
import numpy as np
from tf2_msgs.msg import TFMessage
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Transform, Vector3
import numpy as np
import time
import roslib; roslib.load_manifest('ur_driver')
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
# import inverse_kinematics as IK USE VALMIK CODE
# import map_tool_frame as MTF

listener = None

#PRIMARY METHODS

#def grid_gen():
def grid_gen(corner_tag, ar_tag_nums, spacing):
    #rospy.init_node('ar_tags_gridgen')
    # cornerNum = 3;
    # ar_tagnums = np.array([13,14,15,2,3,5,6,7,8])

    listener = tf.TransformListener()
    # Set the board properties
    xspacing = spacing
    yspacing = xspacing
    tol = .06
    direction = -1 #right
    boardLength = np.sqrt(ar_tag_nums.size)
    try:
        grid = np.zeros((ar_tag_nums.size,1))
        grid[0]=corner_tag
        for i in range(0,ar_tag_nums.size): #loop over number of tags
            currentTag = int(grid[i])
            for j in range(0,ar_tag_nums.size): #check all tags
                nextTag = int(ar_tag_nums[j])
                print('Cur',currentTag,'Next',nextTag)
                a=0
                while a == 0:
                    try:
                        (trans, rot) = listener.lookupTransform('ar_marker_'+str(currentTag),'ar_marker_'+str(nextTag), rospy.Time(0))
                        a=1
                    except Exception as e: 
                        a=0

                # print(trans)
                x = trans[1]
                y = trans[0]
                print(x,y)
                # print(direction*x>0)
                # print((abs(x) > (xspacing-tol)))
                # print((abs(x) < (xspacing+tol)))
                if (i+1)%boardLength==0: #check if at end
                     if (abs(x)<tol)&((y < (yspacing+tol)) & (y > (yspacing-tol))):
                        grid[i+1]=nextTag
                        direction = direction*-1
                        break
                elif (abs(y)<tol)& (abs(x) < (xspacing+tol)) & (abs(x) > (xspacing-tol)) & (direction*x>0):
                        grid[i+1]=nextTag
                        break
    except Exception as e:
        print(e)
    return grid

# def init_favorable_pos():
def init_favorable_pos(favorable_pos,joint_states,client,JOINT_NAMES):

    #Input joint_angles
    #1x6 array of UR5 joint angles

    ##Set movement speed
    #This is the default speed (i.e. time to this position) in test_move
    move_speed = 2.0

    g = FollowJointTrajectoryGoal()
    g.trajectory = JointTrajectory()
    g.trajectory.joint_names = JOINT_NAMES
    try:
        g.trajectory.points = [
            JointTrajectoryPoint(positions=joints_pos, velocities=[0]*6, time_from_start=rospy.Duration(0.0)),
            JointTrajectoryPoint(positions=favorable_pos, velocities=[0]*6, time_from_start=rospy.Duration(move_speed))]
        client.send_goal(g)
        client.wait_for_result()
    except KeyboardInterrupt:
        client.cancel_goal()
        raise
    except:
        raise

    #Input joint_angles
    #1x6 array of UR5 joint angles
    #insert code to move UR5 to desired position similar to move1() function from test_move.py

# def move_to_start():
def move_to_start(corner_tag,desired_pos,joint_states,client,JOINT_NAMES):

    #Input joint_angles
    #1x6 array of UR5 joint angles

    ##Solve for robot initial states
    #initial_pos = MTF.map_to_tool(joint_states)

    ##Solve XY IK solution
    #final_states = IK.solveXY(corner_tag,desired_pos,initial_pos)
    
    ##Set movement speed
    #This is the default speed (i.e. time to this position) in test_move
    move_speed = 2.0

    g = FollowJointTrajectoryGoal()
    g.trajectory = JointTrajectory()
    g.trajectory.joint_names = JOINT_NAMES
    try:
        g.trajectory.points = [
            JointTrajectoryPoint(positions=joints_states, velocities=[0]*6, time_from_start=rospy.Duration(0.0)),
            JointTrajectoryPoint(positions=final_states, velocities=[0]*6, time_from_start=rospy.Duration(move_speed))]
        client.send_goal(g)
        client.wait_for_result()
    except KeyboardInterrupt:
        client.cancel_goal()
        raise
    except:
        raise

    #Move the UR5 to first corner of the grid by calling Valmik IK function



    
   